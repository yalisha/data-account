# Academic Tools Plugin

A comprehensive toolkit for academic research and writing, designed for economists, social scientists, and quantitative researchers.

## Skills

### Paper Writing & Editing
- **academic-paper-writer** — Draft and structure academic papers
- **academic-writing-standards** — Enforce academic writing conventions
- **empirical-paper-writing** — Structure empirical research papers (IMRAD)
- **iterative-refinement** — Three-phase write-review-revise loop for manuscripts
- **humanizer** — Remove AI-style patterns from academic text
- **management-science-skills** — Management science paper conventions

### LaTeX
- **latex-econ-model** — LaTeX formatting for economic models
- **latex-tables** — Professional LaTeX tables for regression results
- **beamer-presentation** — LaTeX Beamer slide decks
- **academic-diagram-design** — Academic diagrams and figures

### Econometrics & Data
- **stata-regression** — Stata regression analysis workflows
- **stata-data-cleaning** — Stata data cleaning and preparation
- **r-econometrics** — R econometrics (panel data, IV, DID, RDD)
- **python-panel-data** — Python panel data analysis
- **econ-visualization** — Economic data visualization
- **general-equilibrium-model-builder** — General equilibrium modeling

### Research Workflow
- **research-ideation** — Generate and refine research ideas
- **analyzing-research-papers** — Analyze and critique papers
- **lit-review-assistant** — Systematic literature review
- **scientific-figure-pro** — Publication-quality scientific figures
- **project-organization** — Research project file organization

### Research Tools (English)
- **research-en** — Preliminary research and outline generation
- **research-en-research-add-fields** — Add fields to research outline
- **research-en-research-add-items** — Add items to research outline
- **research-en-research-deep** — Deep research on each item
- **research-en-research-report** — Generate research summary report

### Research Tools (Chinese)
- **research-zh** — 初步研究与大纲生成
- **research-zh-research-add-fields** — 添加研究字段
- **research-zh-research-add-items** — 添加研究对象
- **research-zh-research-deep** — 深度研究
- **research-zh-research-report** — 生成研究报告

### Utilities
- **api-data-fetcher** — Fetch data from APIs
- **find-skills** — Discover available skills
- **playwright-skill** — Browser automation with Playwright
- **web-asset-generator** — Generate web assets
