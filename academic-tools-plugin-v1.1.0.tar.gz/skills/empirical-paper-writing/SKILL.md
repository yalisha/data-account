---
name: empirical-paper-writing
description: Guide for writing empirical academic papers following Research Policy/Management Science style. Use when writing or reviewing academic papers with DID analysis, theory sections, hypothesis development, or LaTeX formatting.
---

# Skill: 实证论文写作 (Empirical Paper Writing)

> 基于 HuggingFace 出口管制论文 + Huang et al. (2024, Research Policy) 写作经验总结

## 1. 论文结构

### 1.1 标准章节结构

```
1. Introduction (~1.5-2页)
2. Theory and Hypotheses (~3页，3个假设)
3. Institutional Context (~2页)
4. Data and Methods (~4-5页)
5. Results (~6-8页)
6. Discussion (~2-3页)
7. Conclusion (~1页)
Appendix: 变量定义表、补充回归结果
```

**总页数目标**: 35-40页（双栏约 20-25页）

### 1.2 各章节核心任务

| 章节 | 核心任务 | 常见错误 |
|------|----------|----------|
| Introduction | 指明方向，不剧透细节 | 太长、包含具体系数 |
| Theory | 构建逻辑链，推导假设 | 只叙述不推导 |
| Context | 让读者理解研究情境 | 与 Methods 重复 |
| Methods | 数据+识别策略 | 缺少识别假设讨论 |
| Results | 展示证据，验证假设 | 解读过度 |
| Discussion | 讨论含义和局限 | 重复 Results |
| Conclusion | 总结贡献 | 引入新内容 |

---

## 2. Introduction 写作规范

### 2.1 结构模板（~7段）

```
P1: 研究背景（宏观重要性）
P2: 研究问题 + 理论张力（competing predictions）
P3: 文献不足（research gap）
P4: 本文方法（data + identification）
P5: 主要发现（qualitative, NO specific numbers）
P6: 贡献（3点）
P7: 章节路线图
```

### 2.2 关键原则

**应该做的**：
- ✓ 简洁（1.5-2页）
- ✓ 定性描述发现（"significant increase"）
- ✓ 只提机制名称，不解释细节
- ✓ 贡献写3点，不多不少

**不应该做的**：
- ✗ 包含具体系数（β=0.208）
- ✗ 包含 p 值（p<0.001）
- ✗ 详细解释机制
- ✗ 讨论异质性结果
- ✗ 使用 `\textit{}` 强调

### 2.3 示例对比

**❌ 错误写法**：
> We find that the DID coefficient is 0.208 (p < 0.001), indicating a 23.1% increase in model output. The coefficient on solo development is positive and highly significant (β = 0.101, p < 0.01).

**✓ 正确写法**：
> We find that export controls led to a significant increase in model output among Chinese developers. This surge is entirely driven by solo development rather than derivative work.

---

## 3. Theory 章节写作规范

### 3.1 结构模板（推荐：~3页，3个假设）

```
3.1 Theoretical Background
    - Competing Theory A (e.g., Threat-Rigidity)
    - Competing Theory B (e.g., Escape-Competition)
    - Gap: 现有理论无法解释的现象
3.2 Hypotheses
    3.2.1 [Effect 1] → H1
    3.2.2 [Mechanism] → H2
    3.2.3 [Quality/Boundary] → H3
```

**关键原则**：
- ✓ 每个假设紧跟其理论推导（不要先推导完再列假设）
- ✓ 假设数量控制在 3 个
- ✓ 异质性分析放入 Results 作为"exploratory findings"
- ✗ 不要为机制起新名字（除非真正原创理论）
- ✗ 不要在 Theory 章节放假设汇总表

### 3.2 假设格式

```latex
\begin{hypothesis}[标签名]
假设内容，用陈述句。
\end{hypothesis}
```

### 3.3 假设数量指南

| 假设数量 | 适用情况 | 示例 |
|----------|----------|------|
| 2 个 | 简单研究 | H1: 主效应, H2: 机制 |
| **3 个** | **标准研究（推荐）** | **H1: 主效应, H2: 机制, H3: 质量** |
| 4 个 | 复杂研究（慎用） | + H4: 异质性（但建议放 exploratory） |

### 3.4 异质性分析的处理

**❌ 错误做法**：将异质性作为正式假设
```latex
\begin{hypothesis}[Heterogeneity]
The effect will be stronger for large organizations.
\end{hypothesis}
```

**✓ 正确做法**：在 Results 中作为探索性分析
```latex
\subsection{Heterogeneity Analysis}
% 不要写 "consistent with Hypothesis 4"
% 改写为 "These exploratory findings illuminate boundary conditions..."
```

### 3.5 机制命名原则

| 情况 | 做法 | 示例 |
|------|------|------|
| 应用现有理论 | 直接引用，不起新名字 | "escape competition framework" |
| 理论微创新 | 简单描述机制 | "pathway switching logic" |
| 真正原创理论 | 可起新名字 | 需要独立论文证明 |

**反例**：本次 HuggingFace 论文最初将机制命名为 "Forced Path Switching Theory"
- 问题：过度声称理论贡献
- 修正：改为 "forced path switching mechanism"，强调是 escape competition 的应用

---

## 4. Context 章节写作规范

### 4.1 结构模板（推荐：~2页，无 subsubsection）

```
3.1 The Policy/Event Background
    (政策背景，直接叙述，不分小节)
3.2 The Platform/Setting
    (研究情境，精简描述)
3.3 The Actors/Subjects
    (研究对象，可含简表)
```

**关键原则**：
- ✓ 只用 2 层结构（`\subsection`，不用 `\subsubsection`）
- ✓ 篇幅控制在 ~2 页
- ✓ 让读者理解研究情境即可
- ✗ 不要在 Context 中讨论识别策略（放 Methods）
- ✗ 不要用 itemize 列出技术字段（改用自然语言）

### 4.2 Context vs Methods 的内容划分

| 内容 | 放在 Context | 放在 Methods |
|------|-------------|--------------|
| 政策背景/事件描述 | ✓ | |
| 平台/数据源简介 | ✓ | |
| 研究对象概况 | ✓ | |
| Exogeneity 讨论 | | ✓ |
| 数据字段定义 | | ✓ |
| 变量构建细节 | | ✓ |
| 识别假设/策略 | | ✓ |

### 4.3 常见问题

| 问题 | 表现 | 修正 |
|------|------|------|
| 层级过深 | 3.1.1, 3.2.1... | 删除 subsubsection |
| 技术化过度 | itemize 列出 6 个数据字段 | 改为一句话概述 |
| Exogeneity 位置错误 | 放在 Context 末尾 | 移到 Methods → Identification Challenges |
| 与 Methods 重复 | 数据细节在两处都写 | Context 只概述，Methods 写细节 |

### 4.4 示例对比

**❌ 错误：itemize 列出数据字段**
```latex
\begin{itemize}
    \item \textit{Timestamp}: precise date and time of model upload
    \item \textit{Organization}: the uploading organization's identifier
    \item \textit{Parent models}: list of base models...
    % ... 6个字段
\end{itemize}
```

**✓ 正确：自然语言概述**
```latex
HuggingFace provides rich metadata including upload timestamps,
organizational affiliations, model dependencies, and community
engagement metrics.
```

---

## 5. Methods 章节写作规范

### 5.1 结构模板

```
4.1 Data Sources
    4.1.1 Primary Data (无 itemize，用自然语言)
    4.1.2 Supplementary Data
4.2 Sample Construction
4.3 Variables
    - Dependent Variables (精简表，只含因变量)
    - Treatment/Control (正文描述，不放表中)
4.4 Estimation Strategy
    4.4.1 Main Specification (DID)
    4.4.2 Event Study
    4.4.3 Robustness (PSM/IV)
4.5 Summary Statistics (Table)
4.6 Identification Challenges (无 subsubsection，连续段落)
```

**关键原则**：
- ✓ 数据字段用自然语言描述，不用 itemize
- ✓ 变量表只含 Dependent Variables，其他变量在正文说明
- ✓ Identification Challenges 用连续段落，不分小节
- ✗ 不要用 itemize 列出 8 个数据字段
- ✗ 不要用 4-panel 大表定义所有变量

### 5.2 数据字段描述

**❌ 错误：itemize 列出字段**
```latex
For each model, we extract:
\begin{itemize}
    \item \textit{Model identifier}: unique ID
    \item \textit{Organization}: the uploading organization
    \item \textit{Timestamp}: date and time
    % ... 8个字段
\end{itemize}
```

**✓ 正确：自然语言一句话**
```latex
For each model, we extract a unique identifier, the uploading
organization, precise upload timestamp, parent models (if any),
cumulative likes and downloads, parameter count, and categorical tags.
```

### 5.3 变量表精简

**❌ 错误：4-panel 大表**
```latex
\begin{tabular}{lll}
\multicolumn{3}{l}{\textit{Panel A: Dependent Variables}} \\
% 5 rows
\multicolumn{3}{l}{\textit{Panel B: Independent Variables}} \\
% 3 rows
\multicolumn{3}{l}{\textit{Panel C: Control Variables}} \\
% 2 rows
\multicolumn{3}{l}{\textit{Panel D: Heterogeneity Variables}} \\
% 2 rows
\end{tabular}
```

**✓ 正确：只保留因变量表**
```latex
\caption{Dependent Variables}
\begin{tabular}{p{3.5cm}p{6cm}p{3cm}}
\textbf{Variable} & \textbf{Definition} & \textbf{Hypothesis} \\
$\ln(1 + \text{Model Count})$ & Log count of models & H1 (Output) \\
$\ln(\text{Avg Likes})$ & Log average likes & H3 (Quality) \\
% 只放因变量，其他在正文描述
\end{tabular}
```

### 5.4 Identification Challenges 写法

**❌ 错误：5 个 subsubsection**
```latex
\subsection{Identification Challenges}
\subsubsection{Parallel Trends} ...
\subsubsection{Spillover Effects} ...
\subsubsection{Anticipation Effects} ...
\subsubsection{Composition Effects} ...
\subsubsection{Exogeneity} ...
```

**✓ 正确：连续段落**
```latex
\subsection{Identification Challenges}

Several challenges warrant discussion. The key identifying assumption
is parallel trends... We assess this through event study analysis.

Spillover effects present a potential concern... Anticipation effects
could bias estimates; however, the surprise nature mitigates this.

Composition effects may arise if... We address this by focusing on
organizations active throughout the observation window.

Finally, we assume treatment timing exogeneity. Several features
support this: the timing was driven by U.S. political considerations...
```

### 5.5 DID 公式标准写法

```latex
Y_{it} = \beta (\text{Treat}_i \times \text{Post}_t) + \gamma X_{it} + \alpha_i + \delta_t + \varepsilon_{it}
```

### 5.6 Event Study 公式

```latex
Y_{it} = \sum_{k \neq -1} \beta_k \cdot \mathbf{1}[\text{Month}_t = k] \times \text{Treat}_i + \alpha_i + \delta_t + \varepsilon_{it}
```

---

## 6. Results 章节写作规范

### 6.1 结构模板

```
5.1 Main Results (H1)
    - Table: DID coefficients (3 columns: baseline, +controls, +industry)
    - Event Study Figure
5.2 Mechanism Analysis (H2)
    - Decomposition Table
    - Mechanism Figure
5.3 Quality Analysis (H3)
    - Quality/Scale tests
5.4 Heterogeneity Analysis (探索性，非假设验证)
    - Subgroup Comparisons
    - 用语: "exploratory findings" / "illuminate boundary conditions"
5.5 Robustness Checks
    - Alternative specifications
    - Placebo tests
5.6 Summary of Findings (可选)
    - 假设验证汇总表（3行，不是4行）
```

### 6.2 结果解读模板

```
Column X shows that the DID coefficient is [value] (p = [value]),
indicating a [magnitude]% [increase/decrease] in [outcome].
This finding [supports/contradicts] Hypothesis [N].
```

### 6.3 表格数量建议

| 表格类型 | 数量 | 说明 |
|----------|------|------|
| Summary Statistics | 1 | 必须 |
| Main DID | 1 | H1 核心结果 |
| Mechanism | 1 | H2 验证 |
| Quality/Scale | 1 | H3 验证 |
| Heterogeneity | 1-2 | 探索性分析 |
| Robustness | 1 | 稳健性 |
| Findings Summary | 1 | 可选，汇总3个假设 |
| **总计** | **6-8** | |

### 6.4 假设验证汇总表格式

```latex
\begin{table}[htbp]
\centering
\caption{Summary of Findings}
\label{tab:findings_summary}
\small
\begin{tabular}{p{2cm}p{3.5cm}p{3.5cm}p{2.5cm}}
\hline
\textbf{Hypothesis} & \textbf{Prediction} & \textbf{Finding} & \textbf{Support} \\
\hline
H1: Output Effect & ... & +20.8\% ($p < 0.001$) & \textbf{Supported} \\
H2: Mechanism & ... & Solo: +10.6\%; Deriv: n.s. & \textbf{Supported} \\
H3: Quality & ... & No significant change & \textbf{Supported} \\
\hline
\end{tabular}
\end{table}
```

**注意**：只放3个正式假设，异质性分析不放入此表

### 6.5 Results 章节顺序原则

**关键原则**：Results 小节顺序必须与 Theory 中假设顺序一致

| Theory 假设顺序 | Results 小节顺序 |
|----------------|-----------------|
| H1: Output Effect | 5.1 Main Effect |
| H2: Mechanism | 5.2 Mechanism Analysis |
| H3: Quality | 5.3 Quality Analysis |

**❌ 错误**：Results 按 H1→H3→H2 顺序（先写质量再写机制）
**✓ 正确**：Results 严格按 H1→H2→H3 顺序

### 6.6 Figure Notes 格式

```latex
% ❌ 错误：使用 figurenotes 环境（需要额外包，易出错）
\begin{figurenotes}
Notes: Figure plots coefficients...
\end{figurenotes}

% ✓ 正确：直接用 \par\small\textit{}
\caption{Event Study: Effect of Export Controls on Model Output}
\label{fig:event_study}
\par\small\textit{Notes: Figure plots coefficients $\beta_k$ from
Equation~\ref{eq:event} with 95\% confidence intervals.}
```

### 6.7 Robustness Checks 写法

**❌ 错误：4 个 subsubsection**
```latex
\subsection{Robustness Checks}
\subsubsection{Alternative Treatment Definition}
\subsubsection{Propensity Score Matching}
\subsubsection{Placebo Tests}
\subsubsection{Alternative Samples}
```

**✓ 正确：连续段落**
```latex
\subsection{Robustness Checks}

We conduct several robustness checks to assess the validity of our
findings. First, we examine alternative treatment definitions...

Second, to address potential selection bias, we implement propensity
score matching... Table~\ref{tab:psm} reports these results.

Third, we conduct placebo tests assigning random treatment dates...
The null results from placebo tests support our identification strategy.

Finally, we examine alternative sample constructions...
```

### 6.8 Preview/Summary 段落

**不要**在 Results 开头放 preview 段落总结所有发现，直接进入第一个 subsection

**❌ 错误**：
```latex
\section{Results}

This section presents our empirical findings. We first show that
export controls increased model output (H1). We then demonstrate
that this surge was driven by solo development (H2). Finally, we
show that quality remained stable (H3).

\subsection{Main Effect: Output Surge}
```

**✓ 正确**：
```latex
\section{Results}
\label{sec:results}

\subsection{Main Effect: Output Surge}
Table~\ref{tab:main_did} presents our main DID results...
```

---

## 7. Discussion 章节写作规范

### 7.1 结构模板（推荐：~2-3页，3 subsections，无 subsubsection）

```
6.1 Theoretical Implications (连续段落)
    - First, ... Second, ... Third, ...
6.2 Policy Implications (连续段落)
    - 政策含义、短期vs长期效应
6.3 Limitations and Future Research (连续段落)
    - First, ... Second, ... Third, ... Finally, ...
```

**关键原则**：
- ✓ 只用 3 个 subsection（Theoretical, Policy, Limitations）
- ✓ 每个 subsection 用连续段落，不用 subsubsection
- ✓ 篇幅控制在 2-3 页（~60行）
- ✗ 不要用 subsubsection（如 6.1.1, 6.2.1）
- ✗ 不要加 "Broader Implications" 小节（与 Policy 重复）

### 7.2 Theoretical Implications 写法

**❌ 错误：每个贡献用 subsubsection**
```latex
\subsection{Theoretical Contributions}
\subsubsection{First Contribution: Micro-Level Evidence}
\subsubsection{Second Contribution: Mechanism Identification}
\subsubsection{Third Contribution: Heterogeneous Response}
```

**✓ 正确：连续段落**
```latex
\subsection{Theoretical Implications}

This study makes three contributions to the literature.

First, we provide the first micro-level evidence on how export
controls affect innovation in open-source AI ecosystems...

Second, we identify and validate a novel mechanism---forced path
switching---that explains how sanctions alter innovation patterns...

Third, we demonstrate that organizational capabilities determine
the capacity to respond to external shocks...
```

### 7.3 Limitations 写法

**❌ 错误：5 个 subsubsection**
```latex
\subsection{Limitations and Future Research}
\subsubsection{Short Observation Window}
\subsubsection{Hidden Dependencies}
\subsubsection{Platform Representativeness}
\subsubsection{Causal Mechanisms}
\subsubsection{Quality Measurement}
```

**✓ 正确：2-3 段连续文字**
```latex
\subsection{Limitations and Future Research}

Our study has several limitations that suggest directions for
future research.

First, our 10-month panel captures immediate responses but cannot
distinguish short-term reactions from persistent changes. Second,
our classification relies on explicit declarations which may miss
implicit dependencies...

Third, HuggingFace may not fully represent China's AI ecosystem.
Fourth, the evidence for our mechanism is correlational. Finally,
our quality measures are imperfect proxies...
```

---

## 8. Conclusion 章节写作规范

### 8.1 结构模板（推荐：~1页，15-20行）

```
P1: 研究目标和方法（1-2句）
P2: 主要发现（"three main findings"，与假设数量一致）
P3: 机制解释（1-2句）
P4: 三个贡献（简要重申）
P5: 政策启示（2-3句）
```

**关键原则**：
- ✓ "N main findings" 必须与 Theory 中假设数量一致
- ✓ 篇幅控制在 ~1 页
- ✗ 不要引入新的发现或内容
- ✗ 不要写 Future Research（已在 Discussion 写过）

### 8.2 发现数量一致性

**❌ 错误："four main findings"（假设只有3个）**
```latex
Our analysis yields four main findings. First, ... Second, ...
Third, ... Fourth, the effect is concentrated among large organizations.
```

**✓ 正确："three main findings"（与3个假设对应）**
```latex
Our analysis yields three main findings. First, export controls
increased model output (H1). Second, this surge was driven by solo
development (H2). Third, quality did not decline (H3).
```

**注意**：异质性分析不是正式假设，不应计入 "main findings"

---

## 9. LaTeX 格式规范

### 9.1 表格模板

```latex
\begin{table}[htbp]
\centering
\caption{表格标题}
\label{tab:label}
\small
\begin{tabular}{lccc}
\hline
\textbf{Variable} & \textbf{(1)} & \textbf{(2)} & \textbf{(3)} \\
\hline
Treat $\times$ Post & 0.107*** & 0.208*** & 0.195*** \\
& (0.032) & (0.045) & (0.048) \\
\hline
Organization FE & Yes & Yes & Yes \\
Month FE & Yes & Yes & Yes \\
Observations & 5,214 & 5,214 & 5,214 \\
\hline
\end{tabular}
\par\small\textit{
Notes: Robust standard errors in parentheses. \\
*** p<0.01, ** p<0.05, * p<0.1.
}
\end{table}
```

### 9.2 表格 Panel 分隔

```latex
\hline
\multicolumn{4}{l}{\textit{Panel A: Main Results}} \\
\hline
```

### 9.3 表格 Notes 格式

```latex
% 正确方式（无需额外包）
\par\small\textit{
Notes: 说明内容。
}

% 错误方式（需要 threeparttable 包）
\begin{tablenotes}
\item Notes: ...
\end{tablenotes}
```

### 9.4 `\textit{}` 使用规则

| 场景 | 是否使用 | 示例 |
|------|----------|------|
| 表格 Panel 标题 | ✓ | `\textit{Panel A}` |
| 表格 Notes | ✓ | `\par\small\textit{Notes:}` |
| 数据变量列表 | ✓ | `\item \textit{Variable}: definition` |
| 正文强调词 | ✗ | ~~\textit{whether}~~ → whether |
| 研究问题 | ✗ | ~~\textit{How do...?}~~ → How do...? |
| 首次引入术语 | 可选 | "forced path switching" 或 \textit{} |

---

## 10. 引用规范

### 10.1 文内引用

```latex
% 作者在句中
\cite{huang2024forced} find that...

% 作者在括号中
Recent evidence supports this view \citep{huang2024forced}.

% 多个引用
\citep{aghion2005competition, bloom2016trade}
```

### 10.2 BibTeX 条目类型

| 类型 | 用途 | 必填字段 |
|------|------|----------|
| @article | 已发表期刊 | author, title, journal, year, volume, pages |
| @unpublished | Working paper | author, title, year, howpublished |
| @inproceedings | 会议论文 | author, title, booktitle, year |
| @book | 书籍 | author, title, publisher, year |

### 10.3 Working Paper 格式

```bibtex
@unpublished{author2024title,
  author = {Author, First and Author, Second},
  title = {Paper Title},
  year = {2024},
  howpublished = {NBER Working Paper No. 12345}
}
```

---

## 11. 常见问题与解决

### 11.1 编译错误

| 错误 | 原因 | 解决 |
|------|------|------|
| `tablenotes` undefined | 缺少包 | 改用 `\par\small\textit{}` |
| Missing character | Unicode 字符 | 用 xelatex 编译 |
| Bibliography not found | 路径错误 | 复制 .bib 到同目录 |
| Label may have changed | 交叉引用 | 多编译几次 |

### 11.2 写作问题

| 问题 | 解决方案 |
|------|----------|
| Introduction 太长 | 删除具体数字，只保留定性描述 |
| Theory 缺乏逻辑 | 先写 competing predictions，再推导 |
| Results 解读过度 | 只说 "supports H1"，不过度引申 |
| 全文太长 | 检查是否有重复内容 |

---

## 12. 高质量期刊风格参考

### 12.1 Research Policy / Management Science 风格

- Introduction: 1.5-2页，不含具体系数
- Theory: 清晰的 hypothesis 编号
- Methods: 详细的识别策略讨论
- Tables: 简洁，3-4列为主

### 12.2 检查清单

**结构检查**：
- [ ] Introduction < 2页，无具体 β、p 值
- [ ] Theory ≈ 3页，3个正式假设
- [ ] Context ≈ 2页，无 subsubsection
- [ ] Methods：无 itemize 列出数据字段
- [ ] Methods：变量表只含 Dependent Variables
- [ ] Methods：Identification Challenges 无 subsubsection
- [ ] Exogeneity 讨论在 Methods 而非 Context
- [ ] 每个 Hypothesis 有对应的 Table
- [ ] 异质性分析作为 "exploratory findings"

**Results 检查**：
- [ ] Results 小节顺序与 Theory 假设顺序一致（H1→H2→H3）
- [ ] Results 开头无 preview 段落（直接进入 5.1）
- [ ] Robustness Checks 无 subsubsection（用连续段落）
- [ ] Figure notes 格式正确（`\par\small\textit{}`，非 `\begin{figurenotes}`）

**Discussion/Conclusion 检查**：
- [ ] Discussion 只有 3 个 subsection（Theoretical, Policy, Limitations）
- [ ] Discussion 无 subsubsection（每个 subsection 用连续段落）
- [ ] Discussion 无 "Broader Implications" 小节（与 Policy 重复）
- [ ] Discussion 篇幅 ≈ 2-3 页
- [ ] Conclusion 中 "N main findings" 与假设数量一致（3个）
- [ ] Conclusion 篇幅 ≈ 1 页
- [ ] Conclusion 无 Future Research（已在 Discussion 写过）

**图表检查**：
- [ ] Event study 图展示 parallel trends
- [ ] 表格 notes 格式统一（`\par\small\textit{}`）
- [ ] Figure notes 格式统一（`\par\small\textit{}`）
- [ ] Findings Summary 表只含 3 个假设

**格式检查**：
- [ ] 正文无 `\textit{}` 强调词
- [ ] Robustness checks 至少 3 种
- [ ] 引用格式正确（Harvard style）
- [ ] 机制描述不过度声称理论贡献

---

## 13. 模板文件

### 13.1 Elsevier elsarticle 设置

```latex
\documentclass[preprint,12pt,authoryear]{elsarticle}

\usepackage{amssymb}
\usepackage{amsmath}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{hyperref}
\usepackage{natbib}

\newtheorem{hypothesis}{Hypothesis}

\journal{Research Policy}

\bibliographystyle{elsarticle-harv}
```

### 13.2 文件结构

```
paper/
├── main.tex           # 主文件
├── references.bib     # 参考文献
├── sections/
│   ├── introduction.tex
│   ├── theory.tex
│   ├── context.tex
│   ├── methods.tex
│   ├── results.tex
│   ├── discussion.tex
│   └── conclusion.tex
└── figures/
    ├── event_study.png
    └── mechanism.png
```

### 13.3 编译命令

```bash
cd paper/
xelatex -interaction=nonstopmode main.tex
bibtex main
xelatex -interaction=nonstopmode main.tex
xelatex -interaction=nonstopmode main.tex
```

---

## 14. 参考案例

### 14.1 优秀论文参考

- **Huang et al. (2024)** "Forced to be First" - Research Policy
  - DID + 专利数据
  - 3个正式假设 (H1-H3)，异质性放入 Results
  - Introduction 约 1.5 页，无具体系数
  - Theory 约 3 页，不起新理论名称
  - 机制验证通过分解分析（而非单独假设）

### 14.2 本地示例

```
/Users/mac/computerscience/8Hf平台治理/manusricpt/初稿/
Forced-to-Go-Solo-U.S.-Export-Controls-and-Chinese-AI-Innovation-on-Open-Source-Platforms/
```

---

## 15. 常见过度写作问题

### 15.1 Theory 章节过度问题

| 问题 | 表现 | 修正 |
|------|------|------|
| 假设过多 | 4-5个假设 | 精简到3个，异质性放exploratory |
| 理论命名过度 | "Forced Path Switching Theory" | 改为 "mechanism" 或 "logic" |
| 小节过多 | 3.1.1, 3.1.2, 3.2.1... | 扁平化，减少层级 |
| 汇总表 | 在Theory末尾放假设汇总表 | 删除，汇总放Results |
| 篇幅过长 | 5+页 | 压缩到3页 |

### 15.2 修正示例

**Before (过度)**:
```
Section 3: Theory and Hypotheses (5 pages)
├── 3.1 Theoretical Background
│   ├── 3.1.1 Threat-Rigidity Thesis
│   └── 3.1.2 Escape Competition Framework
├── 3.2 Forced Path Switching: A Novel Theoretical Framework
│   ├── 3.2.1 Core Logic
│   ├── 3.2.2 Pathway Comparison
│   └── 3.2.3 Boundary Conditions
├── 3.3 Hypothesis Development
│   ├── H1: Output Effect
│   ├── H2: Quality Resilience
│   ├── H3: Mechanism
│   └── H4: Heterogeneity
└── 3.4 Summary Table
```

**After (精简)**:
```
Section 3: Theory and Hypotheses (3 pages)
├── 3.1 Theoretical Background
│   (competing predictions in one section)
└── 3.2 Hypotheses
    ├── 3.2.1 Export Controls and Innovation Output → H1
    ├── 3.2.2 Solo versus Derivative Development → H2
    └── 3.2.3 Quality Resilience → H3
```

### 15.3 Context 章节过度问题

| 问题 | 表现 | 修正 |
|------|------|------|
| 层级过深 | 3.1.1, 3.2.1... | 删除 subsubsection |
| itemize 列表 | 列出 6 个数据字段 | 改为自然语言 |
| Exogeneity 位置错误 | 放在 Context 末尾 | 移到 Methods |
| 篇幅过长 | 3+ 页 | 压缩到 2 页 |

### 15.4 Methods 章节过度问题

| 问题 | 表现 | 修正 |
|------|------|------|
| itemize 列表过多 | 3个 itemize 列出 18 个字段 | 全部改为自然语言 |
| 变量表过大 | 4-panel 表（12行） | 精简为因变量表（5行） |
| Identification 小节过细 | 5 个 subsubsection | 合并为 4 个连续段落 |
| 篇幅过长 | 6+ 页（222行） | 压缩到 4-5 页（165行） |

**修正示例**：

**Before (过度)**:
```
Section 4: Data and Methods (222 lines)
├── 4.1 Data Sources
│   ├── 4.1.1 HuggingFace Hub ← itemize 8项
│   ├── 4.1.2 Organization Data ← itemize 5项
│   └── 4.1.3 Country Assignment
├── 4.2 Sample Construction
│   └── 4.2.1 Panel Structure ← itemize 5项
├── 4.3 Variables
│   └── Table: 4-panel, 12 rows
├── 4.5 Identification Challenges
│   ├── 4.5.1 Parallel Trends
│   ├── 4.5.2 Spillover Effects
│   ├── 4.5.3 Anticipation Effects
│   ├── 4.5.4 Composition Effects
│   └── 4.5.5 Exogeneity
```

**After (精简)**:
```
Section 4: Data and Methods (165 lines, -26%)
├── 4.1 Data Sources
│   ├── 4.1.1 HuggingFace Hub ← 一句话列举字段
│   ├── 4.1.2 Organization Data ← 一句话列举字段
│   └── 4.1.3 Country Assignment
├── 4.2 Sample Construction
│   └── 4.2.1 Panel Structure ← 一句话列举变量
├── 4.3 Variables
│   └── Table: 只含 Dependent Variables (5 rows)
├── 4.5 Identification Challenges ← 连续段落，无 subsubsection
```

### 15.5 Results 章节过度问题

| 问题 | 表现 | 修正 |
|------|------|------|
| 章节顺序错误 | H1→H3→H2（不匹配Theory） | 按 H1→H2→H3 重排 |
| figurenotes 格式错误 | `\begin{figurenotes}` | 改为 `\par\small\textit{}` |
| Robustness 小节过细 | 4 个 subsubsection | 合并为连续段落 |
| Preview 段落多余 | 开头总结所有发现 | 删除，直接进入5.1 |
| 篇幅过长 | 8+ 页（335行） | 压缩到 7 页（318行） |

**修正示例**：

**Before (过度)**:
```
Section 5: Results (335 lines)
├── Preview paragraph (总结H1/H2/H3)
├── 5.1 Main Effect (H1)
├── 5.2 Quality Analysis (H3) ← 顺序错误！
├── 5.3 Mechanism Analysis (H2) ← 顺序错误！
├── 5.4 Heterogeneity
├── 5.5 Robustness Checks
│   ├── 5.5.1 Alternative Treatment ← subsubsection
│   ├── 5.5.2 PSM
│   ├── 5.5.3 Placebo Tests
│   └── 5.5.4 Alternative Samples
└── 5.6 Summary
└── Figures: \begin{figurenotes}... ← 格式错误
```

**After (精简)**:
```
Section 5: Results (318 lines, -5%)
├── 5.1 Main Effect (H1)
├── 5.2 Mechanism Analysis (H2) ← 顺序正确
├── 5.3 Quality Analysis (H3) ← 顺序正确
├── 5.4 Heterogeneity
├── 5.5 Robustness Checks ← 连续段落，无 subsubsection
└── 5.6 Summary
└── Figures: \par\small\textit{Notes: ...} ← 格式正确
```

### 15.6 Discussion/Conclusion 章节过度问题

| 问题 | 表现 | 修正 |
|------|------|------|
| subsubsection 过多 | 13 个 subsubsection | 全部删除，改为连续段落 |
| Broader Implications 多余 | 与 Policy Implications 重复 | 删除整个小节 |
| Theoretical "Contributions" 命名 | 标题叫 Contributions | 改为 "Implications" |
| Limitations 小节过细 | 5 个单独小节 | 合并为 2-3 段 |
| Conclusion "four findings" | 与 3 个假设不一致 | 改为 "three findings" |
| Discussion 篇幅过长 | 4+ 页（96行） | 压缩到 2-3 页（35行） |

**修正示例**：

**Before (过度)**:
```
Section 6: Discussion (96 lines)
├── 6.1 Theoretical Contributions
│   ├── 6.1.1 First Contribution       ← subsubsection
│   ├── 6.1.2 Second Contribution      ← subsubsection
│   └── 6.1.3 Third Contribution       ← subsubsection
├── 6.2 Policy Implications
│   ├── 6.2.1 Double-Edged Sword       ← subsubsection
│   ├── 6.2.2 Short vs Long Term       ← subsubsection
│   ├── 6.2.3 For U.S. Policymakers    ← subsubsection
│   └── 6.2.4 For Chinese Policymakers ← subsubsection
├── 6.3 Limitations and Future Research
│   ├── 6.3.1 Short Window             ← subsubsection
│   ├── 6.3.2 Hidden Dependencies      ← subsubsection
│   ├── 6.3.3 Platform                 ← subsubsection
│   ├── 6.3.4 Causal Mechanisms        ← subsubsection
│   └── 6.3.5 Quality Measurement      ← subsubsection
└── 6.4 Broader Implications           ← 与 6.2 重复！
    ├── 6.4.1 Technology Containment
    ├── 6.4.2 Innovation in Constraints
    └── 6.4.3 Future of Open-Source AI

Section 7: Conclusion (18 lines)
└── "four main findings"               ← 与3个假设不一致！
```

**After (精简)**:
```
Section 6: Discussion (35 lines, -64%)
├── 6.1 Theoretical Implications ← 连续段落 (First, Second, Third)
├── 6.2 Policy Implications      ← 连续段落
└── 6.3 Limitations and Future Research ← 2段连续文字

Section 7: Conclusion (17 lines)
└── "three main findings"        ← 与3个假设一致
```

---

*Last Updated: 2026-01-14*
*Based on: HuggingFace Export Control Paper + Huang et al. (2024) Reference*
*Iterations:*
- *Theory section rewrite (4→3 hypotheses, remove summary table)*
- *Context section rewrite (flatten structure, move Exogeneity to Methods)*
- *Methods section rewrite (itemize→prose, table 4-panel→1-panel, 5 subsubsections→paragraphs)*
- *Results section rewrite (H1→H2→H3 order, figurenotes→\par\small\textit{}, Robustness 4 subsubsections→paragraphs, remove preview paragraph)*
- *Discussion section rewrite (13 subsubsections→0, delete Broader Implications, Contributions→Implications, 96→35 lines)*
- *Conclusion section rewrite ("four findings"→"three findings")*
