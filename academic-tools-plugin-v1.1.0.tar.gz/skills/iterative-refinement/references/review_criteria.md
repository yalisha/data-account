# Review Criteria Reference

## Academic Mode Criteria

### Scoring Rubric (1-5 scale)

Each criterion is scored independently. The **overall score** is a weighted average.

#### Criterion Weights

ACADEMIC_WEIGHTS = {
    "venue_conformity":    0.18,  # Does the content match the target venue's structural template?
    "argument_clarity":    0.16,  # Is the main argument clear and well-structured?
    "evidence_support":    0.16,  # Are claims backed by data/citations?
    "logical_flow":        0.14,  # Do paragraphs and sections connect logically?
    "project_standards":   0.12,  # Does the content comply with project-specific writing rules?
    "writing_quality":     0.12,  # Conciseness, precision, academic tone
    "statistical_rigor":   0.06,  # Proper reporting of methods and results
    "citation_coverage":   0.06,  # Relevant and current references
}

### Venue Conformity (0.18) - Detailed Rubric

This criterion addresses the most common and costly failure mode: producing well-written content that doesn't match the target venue's conventions. A beautifully written introduction that is half the expected length or missing embedded literature review is worse than a rough draft with correct structure, because structural errors require complete rewrites while quality errors require only polishing.

**Score 5**: Matches venue template on all dimensions: length (within 10%), section structure, citation style, conclusion format, contribution count, presence/absence of specific sections.
**Score 4**: Minor deviations (length within 20%, citation style mostly correct, structure matches).
**Score 3**: Some structural deviations (e.g., intro slightly short, conclusion has extra subsections not in template).
**Score 2**: Major structural mismatch (e.g., intro missing literature review when template requires it, conclusion includes limitations when template doesn't).
**Score 1**: Completely wrong structure (e.g., wrote a 1-page intro when venue expects 3 pages with embedded lit review).

Checks:
- Target length: compare word/character count against venue template (within 20% = OK)
- Section structure: does the section contain the expected components?
  - Introduction: literature review embedded or separate? How many topic streams?
  - Conclusion: summary-only, summary+policy, or summary+theory+policy+limitations?
- Citation style: parenthetical footnotes vs author-as-subject ratio
- Contribution format: numbered? How many points?
- Specific structural notes from the venue template

**OVERRIDE RULE**: venue_conformity score <= 2.0 forces NEEDS_REVISION regardless of overall score.

### Project Standards (0.12) - Detailed Rubric

This criterion ensures compliance with project-specific writing rules from CLAUDE.md or equivalent instruction files.

**Score 5**: All project rules satisfied, no violations detected.
**Score 4**: One minor violation (e.g., one paragraph slightly exceeds author-subject sentence limit).
**Score 3**: 2-3 minor violations or 1 major violation.
**Score 2**: Multiple major violations (e.g., several paragraphs with literature-survey-style author-subject sentences).
**Score 1**: Systematic non-compliance (e.g., entire section uses prohibited writing patterns).

Common project rules to check:
- Citation anti-pattern: count consecutive sentences with scholar names as subject per paragraph
- Structural requirements per subsection (e.g., "framework first, then literature")
- Required analytical elements (e.g., "literature juxtaposition", "divergence sourcing", "evidence quality evaluation")
- Prohibited patterns (e.g., "no coefficients in introduction", "no limitations in conclusion")

**OVERRIDE RULE**: project_standards score <= 2.0 forces NEEDS_REVISION regardless of overall score.

### Convergence Threshold

- **Score >= 4.0** AND **no major issues** -> CONVERGED
- **Score >= 3.5** AND **round = max_rounds** -> CONVERGED (accept with minor fixes)
- **venue_conformity <= 2.0 OR project_standards <= 2.0** -> NEEDS_REVISION (override)
- Otherwise -> NEEDS_REVISION

### Severity Levels

**Strict** (journal-ready):
- All criteria scored individually
- Major issues block convergence regardless of score
- venue_conformity and project_standards have effective veto power

**Balanced** (default):
- Standard weights as configured above
- 1-2 minor issues acceptable for convergence
- Override rules still apply for venue_conformity and project_standards

**Lenient** (early draft):
- Focus on argument_clarity, logical_flow, and venue_conformity only
- Score >= 3.0 allows convergence
- Writing polish deferred to later rounds
- Override rules still apply for venue_conformity

---

## Code Mode Criteria

### Scoring Rubric (1-5 scale)

CODE_WEIGHTS = {
    "correctness":        0.25,
    "readability":        0.20,
    "maintainability":    0.15,
    "performance":        0.10,
    "test_coverage":      0.10,
    "api_design":         0.10,
    "security":           0.10,
}

### Code-Specific Review Checklist

- [ ] No obvious bugs or logic errors
- [ ] Edge cases handled appropriately
- [ ] Follows project conventions (from CLAUDE.md)
- [ ] Functions are focused and reasonably sized
- [ ] Variable/function names are descriptive
- [ ] No security vulnerabilities (injection, XSS, etc.)
- [ ] Performance is acceptable for expected input sizes
- [ ] Error handling is appropriate (not excessive)

---

## Review Output Format

Reviewers MUST produce output in this exact structure:

```markdown
## Summary Assessment
[2-3 sentences on overall quality]

## Score: X.X/5.0

## Venue Conformity Detail
- Target length: {template} vs actual: {measured} -> [OK|TOO SHORT|TOO LONG]
- Structure match: [list specific conformity/deviation items]
- Citation style: [conformity assessment]

## Project Standards Compliance
- [For each rule: PASS or VIOLATION with location]

## Major Issues (must fix before convergence)
1. **[Category]** at [location]: [description] -> [suggested fix]

## Minor Issues (should fix)
1. **[Category]** at [location]: [description] -> [suggested fix]

## Strengths
1. [specific strength]

## Verdict: CONVERGED | NEEDS_REVISION
```
