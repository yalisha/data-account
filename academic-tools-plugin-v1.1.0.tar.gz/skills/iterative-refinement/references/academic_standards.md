# Academic Review Standards (Extracted from Skills)

These concrete rules are embedded into the reviewer agent prompt. They come from
`academic-writing-standards` and `empirical-paper-writing` skills, plus lessons
learned from real-world usage.

## Venue Structural Template Extraction

### Why This Matters

The single most impactful improvement to iterative refinement quality is providing a reference paper from the target venue. Without it, the writer and reviewer fall back on generic academic conventions (e.g., "7-paragraph introduction template") that may be completely wrong for the target venue. For example:

- 会计研究 expects ~3 page introductions with embedded literature review organized by topic streams and ultra-short conclusions (one paragraph + numbered policy implications, NO limitations section)
- IRFA expects ~1.5 page introductions with a separate literature review section and longer conclusions with theory implications, policy implications, and limitations
- Management Science expects very concise introductions but detailed methodology

### Template Fields to Extract

When reading a reference paper, extract these fields for each relevant section:

```
VENUE_TEMPLATE = {
  // For introduction
  introduction: {
    approximate_length: "~3 pages / ~3500 chars / etc.",
    contains_literature_review: true/false,
    literature_organization: "by_topic_stream" | "by_chronology" | "by_method",
    num_topic_streams: number (if by_topic_stream),
    citation_density: "high (>20 per page)" | "medium" | "low",
    citation_style: "parenthetical_footnote" | "author_as_subject" | "mixed",
    max_author_subject_per_paragraph: number,
    includes_specific_results: true/false (some venues put coefficients in intro),
    contribution_format: "numbered (1)(2)(3)" | "bullet" | "prose",
    number_of_contributions: number,
    ends_with_roadmap: true/false,
  },
  // For conclusion
  conclusion: {
    approximate_length: "~1 paragraph" | "~1 page" | "~2 pages",
    format: "summary+numbered_policy" | "summary+theory+policy+limitations" | "summary_only",
    has_limitations_section: true/false,
    has_theory_implications: true/false,
    has_future_research: true/false,
    policy_format: "numbered (1)(2)..." | "prose paragraphs" | "none",
  },
  // For other sections as needed
  specific_notes: ["free text observations"]
}
```

### How to Use the Template

1. **Writer prompt**: Include the full template and instruct "STRICTLY follow the venue template"
2. **Reviewer prompt**: Include the template under "VENUE STRUCTURAL TEMPLATE" and use it as the primary reference for the venue_conformity criterion
3. **Save to file**: Save as `.refinement/venue_template.md` for reference across rounds

## Project Standards Injection

### Why This Matters

Project-level CLAUDE.md files often contain writing standards that are more specific and stricter than generic academic norms. For example, a project might specify:

- "No more than 1 sentence per paragraph with a scholar name as subject" (stricter than generic advice)
- "Each subsection must pass 5 checks: framework first, literature juxtaposition, divergence sourcing, evidence quality evaluation, contribution linkage"
- "Forbidden: consecutive sentences like 'Hong et al. (2000) found... Yu (2008) proved... Huang (2023) showed...'"

These rules must be injected into both the writer and reviewer prompts. The reviewer must treat violations as major issues equivalent to factual errors.

### Extraction Process

1. Read CLAUDE.md from the project root
2. Extract all items under headings like "Writing Standards", "Academic Writing", "Anti-Patterns", "Writing Rules"
3. Format as a numbered checklist
4. Save to `.refinement/project_standards.md`

## Writing Quality Checklist

### Overused Qualifiers (flag and suggest removal)
- "clearly", "obviously", "evidently" -> let evidence speak
- "very", "quite", "rather" -> use stronger base word
- "significantly" -> reserve for statistical significance only
- "novel", "new" -> show novelty through comparison, don't claim it
- "state-of-the-art" -> demonstrate through benchmarking
- "comprehensive" -> avoid entirely

### Vague Language (flag and require specifics)
- "performed well" -> "achieved 81% accuracy"
- "large dataset" -> "dataset of 1,200 trading days"
- "improved substantially" -> "accuracy improved from 79% to 81%"
- "In recent years" -> specify timeframe or cite growth data

### Sentence Structure
- Prefer active voice over passive
- Avoid excessive em-dashes (use separate sentences instead)
- Avoid semicolons when colon or period works
- Simplify nested clauses into separate sentences
- One idea per sentence

### Redundancy
- "past history" -> "history"
- "end result" -> "result"
- "basic fundamentals" -> "fundamentals"
- "future plans" -> "plans"

## Introduction Anti-Patterns

**NOTE**: The old "7-Paragraph Template" has been removed. Introduction structure should be determined by the venue template extracted from the reference paper (Phase A3), NOT by a one-size-fits-all template. Different venues have very different introduction conventions.

### Universal Anti-Patterns (apply regardless of venue)
- Do NOT include specific coefficients (beta=0.208) in introduction
- Do NOT include p-values in introduction
- Do NOT explain mechanisms in detail (just name them)
- Contributions should be clearly stated and differentiated from existing work
- Each contribution should explain what is new relative to a specific prior paper

### Citation Anti-Patterns
- "A did B" consecutive flow: Multiple consecutive sentences with scholar names as grammatical subjects is a literature review style, not a theory/introduction style. Example of what to avoid:
  "Hong et al. (2000) found that... Yu (2008) proved that... Huang (2023) showed that..."
  Instead, use mechanism/phenomenon as subject with parenthetical citations:
  "Information asymmetry leads to price delay (Hong et al., 2000), and this effect is amplified when analyst coverage is low (Yu, 2008; Huang, 2023)."
- Maximum allowed consecutive author-subject sentences: check project standards (typical: 1 per paragraph)

## Citation Standards
- Check for placeholder citations (@TODO, @CITE)
- Verify consistent citation style throughout
- Ensure proper use of \citet{} vs \citep{} (LaTeX) or equivalent
- Flag excessive self-citation
- Check that all citation keys likely exist in .bib file

## Statistical Reporting
- Report confidence intervals: "estimate (95% CI: lower, upper)"
- p-values: use "p < 0.001" not "p = 0.000"
- Distinguish statistical significance from practical/economic significance
- Define significance thresholds explicitly

## Data Consistency Check

### Why This Matters

Empirical papers contain specific numbers (sample sizes, variable counts, coefficient magnitudes) that must match across sections and match the source data. Common errors include:
- Keyword count stated as 63 but actual code contains 73 keywords
- Sample size stated as 43,847 in one section but 38,614 in another (due to different filtering stages)
- Year range inconsistency (2011-2024 for annual reports vs 2012-2024 for regressions due to lag)

### Checking Process

1. Extract all numbers from the draft: sample sizes, year ranges, variable counts, percentage claims
2. Compare against the data source file (specified in Phase A)
3. Compare against other sections of the same paper
4. Flag mismatches with severity: ERROR (wrong number) vs WARNING (could be different valid views)
5. Auto-fix clear errors, flag ambiguous cases for human review
