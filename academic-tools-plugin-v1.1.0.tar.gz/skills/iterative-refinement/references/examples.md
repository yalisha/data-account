# Example Workflows

## Example 1: Chinese Journal Submission with Reference Paper Analysis (Full Three-Phase)

This example demonstrates the new Phase A reference paper analysis and project standards injection, based on a real case where these features would have prevented multiple rounds of rework.

### Phase A: Discovery & Alignment

```
User: /iterative-refinement

[REFINEMENT] Reading target files...
```

```
AskUserQuestion:
  Q1: "What is the goal for this refinement?"
      -> User selects: "Rewrite section from scratch"
  Q2: "Which mode?"
      -> User selects: "Academic paper"
```

**A3: Reference Paper Analysis**

```
[REFINEMENT] Is there a reference paper from the target venue?
      -> User provides: bib/zhu_kang_2025.pdf (会计研究)
[REFINEMENT] Reading reference paper introduction (pages 1-5) and conclusion (pages 13-16)...
[REFINEMENT] Extracted venue template:

  VENUE_TEMPLATE (会计研究):
    introduction:
      approximate_length: ~3 pages (~3500 chars)
      contains_literature_review: true (embedded, no separate lit review chapter)
      literature_organization: by_topic_stream (3-4 streams)
      citation_density: high (>20 per page)
      citation_style: parenthetical_footnote (scholar names rarely as subject)
      max_author_subject_per_paragraph: 1
      includes_specific_results: false
      contribution_format: numbered (1)(2)(3) in prose
      number_of_contributions: 3
      ends_with_roadmap: true (chapter arrangement paragraph)
    conclusion:
      approximate_length: ~1 paragraph + numbered policy implications
      format: summary+numbered_policy
      has_limitations_section: false
      has_theory_implications: false (merged into summary)
      has_future_research: false
      policy_format: numbered (1)(2)

  Saved to .refinement/venue_template.md
```

**A4: Project Standards Injection**

```
[REFINEMENT] Found CLAUDE.md with writing standards. Extracted 7 rules:
  1. Framework first: each subsection starts with framework/taxonomy, not literature
  2. Literature juxtaposition: at least once per subsection, compare 2+ papers in same sentence
  3. Divergence sourcing: when findings conflict, explain source (measurement, sample, identification, theory)
  4. Evidence quality: distinguish correlation vs causation, note proxy bias, external validity
  5. Contribution linkage: each subsection naturally leads to this paper's contribution
  6. No "A did B" flow: max 1 author-subject sentence per paragraph, rest use mechanism/concept as subject
  7. Reference style: follow Zhu Kang (2025) style - logic-chain driven, citations as footnotes

  Saved to .refinement/project_standards.md
```

**A5: Clarify Scope**

```
[REFINEMENT] Proposed plan:
  Target:   manuscript/01_introduction.md + manuscript/08_conclusion.md
  Mode:     academic
  Rounds:   2
  Venue:    会计研究 (Accounting Research)
  Reference paper: bib/zhu_kang_2025.pdf
  Venue template: intro ~3500 chars with embedded lit review by topic streams;
                  conclusion = 1 paragraph + numbered (1)(2) policy implications
  Project standards: 7 rules extracted
  Severity: strict
  Data source: docs/data_summary.md
```

### Phase B: Automated Loop

**Round 1 Writer** produces ~3500 char introduction with 4 literature topic streams, embedded citations as parenthetical footnotes, 3 numbered contributions, and chapter roadmap. Conclusion is 1 summary paragraph + 2 numbered policy implications.

```
[REFINEMENT] Round 1 Writer phase complete. Draft saved.
```

**Round 1 Reviewer:**

```markdown
## Score: 4.2/5.0
- venue_conformity: 4.5 (x0.18 = 0.81) - length matches, structure matches, citation style correct
- project_standards: 4.0 (x0.12 = 0.48) - 1 minor violation: paragraph 6 has 2 author-subject sentences
- argument_clarity: 4.0 (x0.16 = 0.64)
- evidence_support: 4.5 (x0.16 = 0.72)
- logical_flow: 4.0 (x0.14 = 0.56)
- writing_quality: 4.0 (x0.12 = 0.48)
- statistical_rigor: 5.0 (x0.06 = 0.30) - no coefficients in intro, correct
- citation_coverage: 4.0 (x0.06 = 0.24)
- Weighted total: 4.23

## Venue Conformity Detail
- Target length: ~3500 chars vs actual: ~3400 chars -> OK (within 3%)
- Literature review: embedded in 4 topic streams -> OK (template says 3-4)
- Citation style: 38 parenthetical, 3 author-subject -> OK (ratio matches venue)
- Conclusion: 1 paragraph + (1)(2) policy -> OK (matches template exactly)
- No limitations section -> OK (template says none)

## Project Standards Compliance
- Rule 1 (framework first): PASS
- Rule 2 (literature juxtaposition): PASS (4 instances found)
- Rule 3 (divergence sourcing): PASS
- Rule 4 (evidence quality): PASS
- Rule 5 (contribution linkage): PASS
- Rule 6 (no A-did-B): VIOLATION at paragraph 6 - 2 consecutive author-subject sentences
- Rule 7 (reference style): PASS

## Minor Issues
1. **project_standards** at paragraph 6: "Hong et al. (2000) showed... Yu (2008) proved..."
   -> Rewrite as: "Information asymmetry delays price discovery (Hong et al., 2000), especially
   when analyst coverage is sparse (Yu, 2008)."

## Verdict: CONVERGED (minor fix applied directly)
```

```
[REFINEMENT] Round 1/2: Score 4.2/5 -> CONVERGED (early)
  venue_conformity: 4.5, project_standards: 4.0
```

**B4: Data Consistency Check:**

```
[REFINEMENT] Data consistency check: 0 issues
  - Sample size 38,614: matches data_summary.md
  - Year range 2012-2024: matches
  - 73 keywords: matches (code has 73, correctly stated)
  - 14-year coverage: matches (2011-2024 annual reports)
```

### Phase C: Human Review

User approves with one minor adjustment to a literature comparison.

```
[REFINEMENT] Complete.
  Phase A: 1 alignment round
  Phase B: 1/2 automated round (early convergence)
  Phase C: 1 human review round
  Score: 4.2
  Venue conformity: 4.5 | Project standards: 4.0
  Data consistency: PASS
  Key improvements: venue-conforming structure, embedded lit review, correct citation style
  Status: Approved by human
```

**Key insight**: Without the reference paper analysis, the first round would have produced a ~2000 char introduction with no embedded literature review and a ~1200 char conclusion with theory implications and limitations. This would have required user intervention to redirect, wasting 2+ rounds.

---

## Example 2: IRFA Submission (English, Standard Flow)

### Phase A: Discovery & Alignment

```
AskUserQuestion:
  Q1: "What is the goal for this refinement?"
      -> User selects: "Polish existing draft for submission"
  Q2: "Which mode?"
      -> User selects: "Academic paper"
```

A3: No reference paper provided. Using generic academic defaults.
A4: No CLAUDE.md found. Using generic standards.

```
[REFINEMENT] Proposed plan:
  Target:   sections/introduction.tex
  Mode:     academic
  Rounds:   2
  Venue:    IRFA (International Review of Financial Analysis)
  Reference paper: none (using generic defaults)
  Venue template: generic (limited venue conformity scoring)
  Project standards: none (using generic standards)
  Severity: balanced
```

### Phase B: Automated Loop

**Round 1 Reviewer** uses generic criteria (venue_conformity scored conservatively due to no template):

```markdown
## Score: 3.2/5.0
- venue_conformity: 3.0 (no template, scored conservatively)
- argument_clarity: 3.0
- evidence_support: 2.5
- logical_flow: 3.5
- project_standards: N/A (no project standards)
- writing_quality: 3.5
- statistical_rigor: 4.0
- citation_coverage: 3.0

## Venue Conformity Detail
- No reference paper provided, unable to check venue-specific structure
- Generic checks: word count appropriate, basic IMRAD structure present

## Major Issues
1. **argument_clarity** at paragraph 2: Transition from general to specific lacks reasoning
2. **evidence_support** at paragraph 4: Contribution claims lack comparative citations

## Verdict: NEEDS_REVISION
```

Round 2 addresses feedback, converges at 4.1.

---

## Example 3: Responding to Real Reviewer Comments

### Phase A: Discovery & Alignment

```
AskUserQuestion:
  Q1: "What is the goal for this refinement?"
      -> User selects: "Address specific reviewer comments"
```

User pastes R1 comments. A3: reference paper provided. A4: CLAUDE.md found with 5 rules.

Comments parsed and tracked through rounds. Each review explicitly checks:
```
## Reviewer Comment Status
- R1.1: ADDRESSED - Added bootstrap CI and economic significance discussion
- R1.2: ADDRESSED - Added Chen et al. (2024) and Wang et al. (2025) to literature
- R1.3: ADDRESSED - Table reformatted
- R1.4: ADDRESSED - DWT defined at first use
```

---

## Example 4: Data Consistency Check Catching Real Errors

During Phase B4, the fact-checker compares the draft against the data source file:

```
[REFINEMENT] Data consistency check: 2 issues

  ERROR: Introduction states "五个维度共63个关键词" but data source shows 73 keywords
         (data_stock:15 + data_dev:19 + data_app:19 + data_value:11 + data_gov:9 = 73)
         -> Auto-fixed to "五个维度共73个关键词"

  WARNING: Introduction states "2011-2024年" for observation period, but regression sample
           starts from 2012 (DU_kw uses t-1 lag). Both are technically correct but refer
           to different things (annual reports vs regression sample).
           -> Flagged for human review in Phase C
```

This feature caught a real error (63 vs 73 keywords) that had propagated across 3 sections of a manuscript and would not have been caught by writing quality or venue conformity reviews.

---

## Example 5: Code Module with Working Files

### Phase A
```
Target: 4_experiments/12_advanced_dl_baselines.py
Mode: code
Rounds: 2
```

### Phase B

Working files created:
```
4_experiments/.refinement/
+-- 12_advanced_dl_baselines_original.py
+-- 12_advanced_dl_baselines_round1.py
+-- 12_advanced_dl_baselines_review_round1.md
+-- 12_advanced_dl_baselines_round2.py
+-- 12_advanced_dl_baselines_review_round2.md
+-- 12_advanced_dl_baselines_final.py
```

Round 1 identifies duplicated preprocessing (score 3.5). Round 2 refactors (score 4.3, CONVERGED).

### Phase C

Diff shows extracted base class and fixed GPU detach issue. User approves.
