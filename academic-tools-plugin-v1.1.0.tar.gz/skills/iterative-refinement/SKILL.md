---
description: Three-phase refinement for academic papers and code. Phase A aligns with
  the human on goals and constraints, including reference paper analysis and project
  standards injection. Phase B runs automated write-review-revise loops until quality
  converges, followed by a data consistency check. Phase C collects human feedback
  and applies targeted fixes until sign-off. Use when drafting or polishing
  manuscripts, code modules, or any content that benefits from human-in-the-loop
  iterative critique.
license: MIT license
metadata:
  skill-author: Sam Abbott
name: iterative-refinement
user-invokable: true
---

# Iterative Refinement: Write-Review-Revise Loop

## Overview

This skill orchestrates a **critic loop** workflow: a writer agent produces content, a reviewer agent evaluates it with structured feedback, then a revision agent incorporates the feedback. This cycle repeats for a configurable number of rounds (default: 2-3) until quality stabilizes.

## When to Use This Skill

Use this skill when:
- Drafting or revising academic paper sections (introduction, methods, results, discussion)
- Polishing code modules that need quality review and iteration
- Preparing manuscripts for journal submission and want structured self-critique
- Rewriting sections in response to real reviewer comments (R1/R2 feedback)
- Any content that benefits from write-then-critique-then-improve cycles

Do NOT use for:
- Simple edits (typo fixes, formatting changes)
- First-time exploratory drafts where structure is unclear
- Tasks where a single pass is sufficient

## Workflow Architecture

```
Phase A: Discovery & Alignment (human <-> AI, 1-3 rounds)
    |  [includes reference paper analysis + project standards injection]
    v
Phase B: Automated Loop (write -> review -> revise) x N
    |  [+ data/fact consistency check]
    |  [+ cross-section consistency check if parallel]
    v
Phase C: Human Review & Refinement (human <-> AI, 1-3 rounds)
```

Detailed flow:
```
[A] Human <-> AI: "What do you want? What matters most?"
         <-> AI: "Is there a reference paper for the target venue?"
         <-> AI: [reads reference paper -> extracts structural template]
         <-> AI: [reads CLAUDE.md -> extracts project writing standards]
         <-> AI: "Here's my plan + venue template, agree?"
              |
              v
[B] [Writer] -> [Reviewer] -> [Reviser] ---+
         ^                                 |
         +---------- (if NEEDS_REVISION) --+
              | (CONVERGED or max_rounds)
              v
         [Data Consistency Check]
         [Cross-Section Consistency Check if parallel]
              |
              v
[C] Human <-> AI: "Here's the result + diff. What do you think?"
         <-> AI: applies targeted fixes
         <-> AI: "How about now?" -> final sign-off
```

## Working File Convention

All drafts are saved with round numbers for traceability and diffing:

```
{target_dir}/.refinement/
+-- venue_template.md             # Structural template extracted from reference paper
+-- project_standards.md          # Writing standards extracted from CLAUDE.md
+-- {section}_original.tex        # Backup of original before any changes
+-- {section}_round1.tex          # Draft after round 1
+-- {section}_round2.tex          # Draft after round 2
+-- {section}_review_round1.md    # Reviewer feedback from round 1
+-- {section}_review_round2.md    # Reviewer feedback from round 2
+-- {section}_factcheck.md        # Data consistency check report
+-- {section}_final.tex           # Final approved version
```

For code mode, replace `.tex` with the appropriate extension.

**Diff generation**: Use `git diff --no-index {original} {final}` to show changes in Phase C. If inside a git repo, changes can also be shown via `git diff` on the target file directly.

## Execution Steps

When this skill is invoked, follow all three phases in order.

---

### Phase A: Discovery & Alignment (Pre-loop)

**Goal**: Understand what the human wants, extract venue-specific structural constraints from reference papers, inject project writing standards, and agree on scope before any automated work begins.

**A1: Understand Intent**

Read any existing content the human points to. Then ask:

```
AskUserQuestion:
  Q1: "What is the goal for this refinement?"
      Options: [
        "Polish existing draft for submission",
        "Rewrite section from scratch",
        "Address specific reviewer comments",
        "Improve a specific aspect (clarity, flow, evidence)"
      ]
  Q2: "Which mode?"
      Options: ["Academic paper", "Code module"]
```

**A2: Ingest Reviewer Comments (if goal = "Address specific reviewer comments")**

If the human is responding to real reviewer feedback:

1. Ask: "Please paste the reviewer comments, or point me to the file containing them."
2. Parse comments into a structured list:
   ```
   REVIEWER_COMMENTS = [
     {id: "R1.1", type: "major", text: "...", section: "introduction"},
     {id: "R1.2", type: "minor", text: "...", section: "methods"},
     ...
   ]
   ```
3. Summarize back to the human: "I found {N} major and {M} minor comments targeting sections: {list}. Correct?"
4. These comments become **hard constraints** for the writer: each must be addressed. The reviewer checks whether each comment was adequately addressed.

**A3: Reference Paper Analysis (academic mode, CRITICAL STEP)**

This step prevents the single most common failure mode: producing content that doesn't match the target venue's conventions despite being well-written in the abstract. The writer and reviewer CANNOT guess venue-specific structural norms without seeing a real example.

1. Ask the human: "Is there a reference paper from the target venue I should use as a style template? (PDF path or 'skip')"
2. If a reference paper is provided:
   - Read the relevant sections of the PDF (introduction pages + conclusion pages at minimum)
   - Extract a **structural template** with these specific fields:

   ```
   VENUE_TEMPLATE = {
     section: "{introduction|conclusion|methods|...}",
     approximate_length: "{e.g., ~3 pages, ~2000 chars, ~1 paragraph}",
     contains_literature_review: {true|false},
     literature_organization: "{by_topic_stream|by_chronology|by_method|separate_chapter}",
     citation_style: "{parenthetical_footnote|author_as_subject|mixed}",
     max_author_subject_sentences_per_paragraph: {number},
     conclusion_format: "{summary_paragraph+numbered_policy|summary+theory+policy+limitations|short_summary_only}",
     has_limitations_section: {true|false},
     has_theory_implications: {true|false},
     number_of_contributions: {number},
     specific_structural_notes: ["{free text observations about structure}"]
   }
   ```

   - Save template to `.refinement/venue_template.md`
   - Print the extracted template for human verification

3. If no reference paper is provided, use generic defaults and note that venue conformity scoring will be limited.

**A4: Project Standards Injection (CRITICAL STEP)**

This step ensures the reviewer enforces project-specific writing rules, not just generic academic standards.

1. Check if a project-level CLAUDE.md or similar instruction file exists in the working directory or parent directories.
2. If found, extract all writing-related standards, anti-patterns, and constraints. Common items include:
   - Citation style rules (e.g., "no more than 1 author-as-subject sentence per paragraph")
   - Anti-patterns (e.g., "no literature survey style: consecutive sentences with scholar names as subjects")
   - Structural requirements (e.g., "each subsection must pass 5 checks")
   - Required elements (e.g., "framework first, then literature")
3. Format as a checklist and save to `.refinement/project_standards.md`
4. These standards become **hard constraints** for both writer and reviewer. The reviewer must treat violations as major issues.

**A5: Clarify Scope & Priorities**

Present a brief plan and ask for confirmation:

```
[REFINEMENT] Proposed plan:
  Target:   {file_path or section}
  Mode:     {academic|code}
  Rounds:   {N}
  Venue:    {venue}
  Reference paper: {path or "none"}
  Venue template: {summary of key structural constraints}
  Project standards: {N rules extracted or "none"}
  Focus:    {specific_focus or "all criteria"}
  Severity: {strict|balanced|lenient}
  Reviewer comments: {N_comments or "none"}
  Constraints: {list or "none"}
  Data source file: {path or "none"} (for fact-checking)
```

Ask:
```
AskUserQuestion:
  Q1: "Anything to adjust in this plan?"
      Options: [
        "Looks good, proceed",
        "Change number of rounds",
        "Adjust venue template",
        "Add specific constraints"
      ]
```

**A6: Surface Additional Constraints (optional)**

If the human has specific constraints (e.g., "keep paragraph 2 unchanged", "must cite Smith 2024", "word limit 3000", "preserve all \cite{} references"), capture them here.

Also ask: "Is there a single data source file that all numbers in the manuscript should match? (for the fact-check step)"

Print when alignment is complete:
```
[REFINEMENT] Phase A complete. Plan confirmed.
[REFINEMENT] Mode: {mode} | Rounds: {rounds} | Target: {target}
[REFINEMENT] Venue template: {key constraints summary}
[REFINEMENT] Project standards: {N rules}
[REFINEMENT] Constraints: {constraints_list or "none"}
[REFINEMENT] Data source: {path or "none"}
[REFINEMENT] Creating .refinement/ working directory...
[REFINEMENT] Saving original backup...
[REFINEMENT] Entering automated loop...
```

---

### Phase B: Automated Loop

Before starting: save a copy of the original file to `{target_dir}/.refinement/{section}_original.{ext}`.

#### B1: Writer Phase

**For academic mode**, use the Task tool to launch a writer agent:
- Agent type: `academic-revision-specialist` (if revising) or `general-purpose` (if new)
- Input: existing draft, venue template, project standards, review feedback (rounds 2+), reviewer comments (if any), human constraints
- Output: Complete draft saved to `.refinement/{section}_round{n}.{ext}`
- **LaTeX awareness**: Preserve all `\cite{}`, `\ref{}`, `\label{}` commands. Do not alter LaTeX structure unless the human explicitly asked for it.

**For code mode**, write or revise the code directly following project CLAUDE.md conventions.

**Writer agent prompt template:**
```
Write/revise the following section for [{venue}].

EXISTING DRAFT:
{current_draft}

VENUE STRUCTURAL TEMPLATE (extracted from reference paper, MUST follow):
{venue_template}

PROJECT WRITING STANDARDS (MUST follow, violations are major issues):
{project_standards}

REVIEW FEEDBACK TO ADDRESS (rounds 2+):
{review_feedback}

REAL REVIEWER COMMENTS TO ADDRESS (if any):
{reviewer_comments_list}

HUMAN CONSTRAINTS:
{constraints_list}

REQUIREMENTS:
- {venue_specific_requirements}
- STRICTLY follow the venue template: match the target length, structure, citation style,
  and section format. If the template says "introduction contains embedded literature review
  organized by topic streams", do exactly that. If it says "conclusion is one paragraph +
  numbered policy implications", do exactly that.
- STRICTLY follow project writing standards. If they prohibit consecutive author-subject
  sentences, ensure compliance.
- Write in flowing prose, no bullet points in body text
- Preserve all LaTeX commands (\cite, \ref, \label) unless restructuring is requested
- Follow academic conventions for the target field
- If addressing reviewer comments, explicitly note which comment each change addresses

Output the complete revised section.
```

Print: `[REFINEMENT] Round {n} Writer phase complete. Draft saved to .refinement/{section}_round{n}.{ext}`

#### B2: Reviewer Phase

Launch a reviewer agent using the Task tool. **The review criteria, venue template, and project standards must be embedded directly in the prompt** since sub-agents cannot access skill reference files.

**Reviewer agent prompt template:**
```
You are a critical reviewer for [{venue}]. Review the following {mode} content.

CONTENT TO REVIEW:
{draft_content}

PREVIOUS VERSION (for comparison):
{previous_draft_or_original}

REVIEW MODE: {mode}
SEVERITY: {severity}

--- VENUE STRUCTURAL TEMPLATE (extracted from reference paper) ---
{venue_template}

--- PROJECT WRITING STANDARDS ---
{project_standards}

--- EVALUATION CRITERIA (Academic Mode) ---
Score each criterion on a 1-5 scale. Compute weighted average.

Weights and CONCRETE checks for each:

- venue_conformity (0.18): Does the content match the venue's structural template?
  CHECK: Compare against the venue template above. Check: target length (within 20%),
  section structure (e.g., intro contains lit review if template says so), citation style
  (parenthetical vs author-subject ratio), conclusion format, number of contributions,
  presence/absence of limitations section. A structurally non-conforming draft is a major
  issue regardless of writing quality -- a beautifully written introduction that is half the
  expected length or missing embedded literature review FAILS this criterion.

- project_standards (0.12): Does the content comply with project-specific writing rules?
  CHECK: Go through each rule in the project standards above. Common checks:
  * Citation anti-pattern: count consecutive sentences with scholar names as subject.
    If project standards cap this at 1 per paragraph, flag violations as major issues.
  * Structural requirements: e.g., "framework first, then literature" per subsection.
  * Required elements: e.g., "literature juxtaposition", "divergence sourcing".
  Flag each violation with the specific rule violated.

- argument_clarity (0.16): Is the main argument clear and well-structured?
  CHECK: Contributions should be clearly stated. Introduction should NOT contain specific
  coefficients or p-values. Claims should be logically ordered.

- evidence_support (0.16): Are claims backed by data/citations?
  CHECK: Every claim needs a citation or data reference. Flag vague claims like "performed
  well" (should be "achieved 81% accuracy"). Flag "novel" or "state-of-the-art" without
  benchmarking evidence.

- logical_flow (0.14): Do paragraphs and sections connect logically?
  CHECK: Each paragraph should have one main idea. Transitions between paragraphs should
  be explicit. No abrupt topic jumps. Concepts introduced before used.

- writing_quality (0.12): Conciseness, precision, academic tone.
  CHECK: Flag these specific anti-patterns:
  * Overused qualifiers: "clearly", "obviously", "significantly" (unless statistical),
    "novel", "comprehensive"
  * Vague openers: "In recent years", "It is well known"
  * Excessive em-dashes (use separate sentences)
  * Passive voice where active is clearer
  * Redundancies: "past history", "end result", "basic fundamentals"

- statistical_rigor (0.06): Proper reporting of methods and results.
  CHECK: p-values as "p < 0.001" not "p = 0.000". Distinguish statistical from economic
  significance. Define acronyms on first use.

- citation_coverage (0.06): Relevant and current references.
  CHECK: Consistent citation style. No placeholder citations. Recent literature included.

--- EVALUATION CRITERIA (Code Mode, use if mode=code) ---
- correctness (0.25): No bugs, edge cases handled, .detach() before .numpy() on GPU tensors
- readability (0.20): Descriptive names, no magic numbers, focused functions
- maintainability (0.15): DRY (no duplicated logic), consistent with codebase patterns
- performance (0.10): Acceptable for expected input sizes, no unnecessary copies
- test_coverage (0.10): Key logic paths tested, parameter recovery for statistical models
- api_design (0.10): Clean interfaces, consistent with project conventions
- security (0.10): No injection risks, proper input validation at boundaries

--- CONVERGENCE RULES ---
- Strict: Score >= 4.0 AND no major issues -> CONVERGED
- Balanced: Score >= 4.0 AND no major issues -> CONVERGED; Score >= 3.5 at max_rounds -> CONVERGED
- Lenient: Score >= 3.0 -> CONVERGED (focus on argument_clarity and logical_flow only)
- OVERRIDE: Any venue_conformity or project_standards score <= 2.0 -> force NEEDS_REVISION
  regardless of overall score (structural mismatch is always a blocking issue)

REAL REVIEWER COMMENTS TO CHECK (if any):
{reviewer_comments_list}
-> For each comment, state whether it was adequately addressed: [ADDRESSED/PARTIALLY|NOT ADDRESSED]

Produce output in this EXACT format:

## Summary Assessment
[2-3 sentences: overall quality and key impression]

## Score: X.X/5.0
[Show per-criterion scores and weighted calculation]

## Venue Conformity Detail
- Target length: {template} vs actual: {measured} -> [OK|TOO SHORT|TOO LONG]
- Structure match: [list specific conformity/deviation items]
- Citation style: [conformity assessment]

## Project Standards Compliance
- [For each rule: PASS or VIOLATION with location]

## Reviewer Comment Status (if applicable)
- R1.1: [ADDRESSED|PARTIALLY|NOT ADDRESSED] - brief explanation
- R1.2: ...

## Major Issues (must fix)
1. **[criterion]** at [location]: [description] -> [suggested fix]

## Minor Issues (should fix)
1. **[criterion]** at [location]: [description] -> [suggested fix]

## Strengths
1. [specific strength]

## Verdict: [CONVERGED | NEEDS_REVISION]
```

Save review to `.refinement/{section}_review_round{n}.md`.

Print: `[REFINEMENT] Round {n} Review complete. Score: {score}/5. Verdict: {verdict}`

#### B3: Revision Decision

After the review:

- **If verdict = CONVERGED** or **round = max_rounds**: Stop iterating. Apply any minor fixes directly.
- **If verdict = NEEDS_REVISION** and **round < max_rounds**: Proceed to next round with review feedback.
- **If reviewer comments exist and any are NOT ADDRESSED**: Force NEEDS_REVISION regardless of score (up to max_rounds).
- **If venue_conformity or project_standards scored <= 2.0**: Force NEEDS_REVISION regardless of overall score.

Print:
```
[REFINEMENT] Round {n}/{max}: Score {score}/5 -> {CONVERGED|CONTINUING}
  venue_conformity: {score}, project_standards: {score}
```

#### B4: Data Consistency Check (after loop converges)

**Goal**: Catch factual errors before human review. This step is especially important for empirical papers where specific numbers (sample sizes, keyword counts, coefficient magnitudes, variable definitions) appear across multiple sections and must match a single source of truth.

1. If a data source file was specified in Phase A:
   - Scan the final draft for all numbers, statistics, sample descriptions, and quantitative claims
   - Cross-reference each against the data source file
   - Flag any mismatches (e.g., "introduction says 63 keywords but data source says 73")
   - Save report to `.refinement/{section}_factcheck.md`

2. Even without a specified data source file:
   - Check internal consistency: do numbers mentioned in the current section match numbers in other already-written sections of the same paper?
   - Flag any contradictions

3. Apply fixes for clear errors (wrong numbers). For ambiguous cases, flag for human review in Phase C.

Print:
```
[REFINEMENT] Data consistency check: {N_issues_found} issues
  {list of issues if any}
```

#### B5: Cross-Section Consistency Check (parallel mode only)

If multiple sections were refined in parallel, run a final consistency check after all loops complete:

Launch a reviewer agent with this prompt:
```
Check cross-section consistency for the following refined sections:

SECTIONS:
{list of section names and their final drafts}

Check for:
1. Terminology consistency (same terms for same concepts across sections)
2. No contradictory claims between sections
3. Smooth narrative arc across sections (intro -> methods -> results -> discussion)
4. Consistent citation style and reference usage
5. No duplicated content between sections
6. Numerical consistency (same numbers for same statistics across sections)

Output: list of inconsistencies found, with specific locations and suggested fixes.
```

Apply fixes, then proceed to Phase C.

Print when loop completes:
```
[REFINEMENT] Phase B complete.
  Rounds: {n_rounds_used}/{max_rounds}
  Score progression: {round1_score} -> ... -> {final_score}
  Venue conformity: {final_score}
  Project standards: {final_score}
  Reviewer comments addressed: {n_addressed}/{n_total} (if applicable)
  Data consistency: {PASS|N issues found}
  Cross-section check: {PASS|N issues found} (if parallel)
[REFINEMENT] Entering human review...
```

---

### Phase C: Human Review & Refinement (Post-loop)

**Goal**: Present the result to the human, collect feedback, and iterate until satisfied. This prevents the "AI echo chamber" problem.

**C1: Present Results**

Show the human:
1. Summary of key improvements from the automated loop
2. Score progression and final score, with venue conformity and project standards scores highlighted
3. Diff: run `git diff --no-index .refinement/{section}_original.{ext} .refinement/{section}_round{final}.{ext}` and show
4. Reviewer comment resolution status (if applicable)
5. Data consistency check results (if any issues found)
6. Any remaining minor issues the reviewer flagged

```
AskUserQuestion:
  Q1: "How does the refined version look?"
      Options: [
        "Looks good, finalize it",
        "Good direction, but I have specific feedback",
        "Not what I wanted, let me explain",
        "Show me more detail on the changes"
      ]
```

**C2: Targeted Fixes (if human has feedback)**

1. Parse feedback into specific, actionable items
2. Apply fixes directly (no need to re-enter the full loop)
3. Show each fix and confirm

For substantial feedback (e.g., "the whole argument structure is wrong"), re-enter Phase B with adjusted constraints.

**C3: Iterate Until Sign-off**

```
AskUserQuestion:
  Q1: "Anything else to adjust?"
      Options: [
        "No, this is good. Finalize.",
        "One more thing...",
        "Run another automated round with new constraints"
      ]
```

If "run another automated round": return to Phase B with updated constraints.

**C4: Finalization**

Once approved:
1. Copy final draft from `.refinement/` to the target file
2. Optionally clean up `.refinement/` directory (ask human)
3. Print summary:

```
[REFINEMENT] Complete.
  Phase A: {n_alignment_rounds} alignment rounds
  Phase B: {n_auto_rounds}/{max_rounds} automated rounds
  Phase C: {n_human_rounds} human review rounds
  Score progression: {round1_score} -> ... -> {final_score}
  Venue conformity: {score} | Project standards: {score}
  Reviewer comments: {n_addressed}/{n_total} addressed (if applicable)
  Data consistency: {PASS|N_issues}
  Key improvements: {brief_list}
  Status: Approved by human
```

## Configuration Options

| Parameter | Default | Description |
|-----------|---------|-------------|
| mode | academic | `academic` or `code` |
| rounds | 2 | Max iteration rounds (1-4) |
| venue | generic | Target journal/conference/project |
| severity | balanced | `strict` (journal ready), `balanced`, `lenient` (early draft) |
| focus | all | Specific aspects: `methodology`, `writing`, `logic`, `statistics` |
| reference_paper | none | Path to a published paper from the target venue for style extraction |
| data_source | none | Path to the authoritative data file for fact-checking |

## Mode-Specific Behavior

### Academic Mode

**Writer draws from:**
- Venue structural template (extracted from reference paper in Phase A)
- Project writing standards (from CLAUDE.md)
- scientific-writing skill patterns (IMRAD, flowing prose, citations)
- Field-specific terminology conventions

**Reviewer evaluates** (weights embedded in prompt):
- venue_conformity (0.18), argument_clarity (0.16), evidence_support (0.16)
- logical_flow (0.14), project_standards (0.12), writing_quality (0.12)
- statistical_rigor (0.06), citation_coverage (0.06)

### Code Mode

**Writer follows:**
- Project CLAUDE.md conventions
- Existing codebase patterns

**Reviewer evaluates** (weights embedded in prompt):
- correctness (0.25), readability (0.20), maintainability (0.15)
- performance (0.10), test_coverage (0.10), api_design (0.10), security (0.10)

## Parallel Agent Strategy

For multiple sections, run independent refinement loops simultaneously:
- Use `run_in_background: true` for non-blocking agents
- After all loops complete, run B4 data consistency check and B5 cross-section consistency check
- Then enter Phase C with combined results

## Review Criteria Details

For detailed rubrics per severity level, see `references/review_criteria.md`. Note: these details are for human reference only. Sub-agents receive criteria via embedded prompts, not file references.

## Example Workflows

For worked examples with full three-phase flow, see `references/examples.md`.

## Integration with Other Skills

The reviewer prompt embeds concrete rules extracted from these skills so sub-agents can use them:

- **academic-writing-standards** -> Embedded: qualifier blacklist, vague language detection, sentence structure rules, citation checks
- **empirical-paper-writing** -> Embedded: contribution format, anti-patterns (no coefficients/p-values in intro)
- **humanizer** -> Optional Phase C post-polish: run after human sign-off to remove AI-style patterns
- **peer-review** -> Provides the overall structured review methodology
- **scientific-writing** -> IMRAD structure, flowing prose requirements
- **scholar-evaluation** -> Alternative quantitative scoring framework

See `references/academic_standards.md` for the full extracted rules (human reference only; sub-agents get them via prompt).

## Tips for Best Results

1. **Always provide a reference paper**: The single most impactful thing you can do. A reference paper from the target venue eliminates guesswork about structure, length, and style.
2. **Check your CLAUDE.md**: If the project has writing standards, the skill will auto-inject them. Make sure they are up to date.
3. **Specify a data source file**: For empirical papers, point to your master results file so the fact-check step can catch number mismatches.
4. **Be specific about venue**: "会计研究 submission" gives better feedback than "some journal"
5. **2 rounds is usually enough**: Diminishing returns after round 3 for most content
6. **Review the reviews**: Skim the reviewer output before auto-applying, override if needed
7. **Section by section**: Run the loop on individual sections, not entire papers at once
8. **Paste real reviewer comments**: The skill tracks whether each is addressed across rounds
