---
name: academic-diagram-design
description: Guide for designing academic paper architecture diagrams in SVG format. Use when creating or improving research paper figures, neural network diagrams, or system architecture visualizations with Nature/Science journal style.
---

# Skill: 学术论文架构图设计 (SVG)

> 基于 COH-GAT 项目架构图迭代经验总结

## 1. 配色方案

### 1.1 Nature 风格单色系（推荐）

```
创新点1: #4DBBD5 (浅青蓝)  背景: #DDF0F5
创新点2: #3C5488 (深蓝)    背景: #E0E5EE
创新点3: #00A087 (青绿)    背景: #D4F0EB
创新点4: #7E6148 (棕灰)    背景: #EDE8E3
标准模块: #333333 边框     背景: #F5F5F5
```

**特点**：冷色为主 + 暖色点缀，饱和度统一，黑白打印友好

### 1.2 ColorBrewer 科学配色

```
绿色系: #1A9850 / #D9F0D3 (Teal)
紫色系: #762A83 / #E7D4E8
蓝色系: #4393C3 / #DEEBF7
红色系: #D6604D / #FEE0D2 (Terracotta)
```

**适用**：需要更强对比度时使用

### 1.3 避免的配色

- ❌ 渐变色（看起来不专业）
- ❌ 纯红色（暗示错误）
- ❌ 高饱和度鲜艳色（Material Design 原色）
- ❌ 过多颜色（超过5种主色）

---

## 2. SVG 基础模板

### 2.1 文件头部

```xml
<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1100 580">
  <defs>
    <marker id="arrow" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto">
      <polygon points="0 0, 8 3, 0 6" fill="#333"/>
    </marker>
  </defs>

  <!-- Background -->
  <rect width="1100" height="580" fill="white"/>

  <!-- Content here -->
</svg>
```

### 2.2 常用元素

**矩形模块**：
```xml
<rect x="35" y="82" width="150" height="45" fill="#f5f5f5" stroke="#333" stroke-width="1"/>
<text x="110" y="100" text-anchor="middle" font-family="Times New Roman, serif" font-size="11" font-weight="bold">模块名称</text>
```

**圆形节点**：
```xml
<circle cx="275" cy="105" r="20" fill="#f5f5f5" stroke="#333" stroke-width="1"/>
<text x="275" y="110" text-anchor="middle" font-family="Times New Roman, serif" font-size="11" font-weight="bold">C</text>
```

**带箭头连线**：
```xml
<line x1="200" y1="190" x2="230" y2="190" stroke="#333" stroke-width="1.5" marker-end="url(#arrow)"/>
```

**虚线边框（模块组）**：
```xml
<rect x="20" y="50" width="180" height="280" fill="none" stroke="#333" stroke-width="1" stroke-dasharray="4,2"/>
```

**创新点高亮**：
```xml
<rect x="35" y="261" width="150" height="60" fill="#D4F0EB" stroke="#00A087" stroke-width="1.5"/>
<text ... fill="#00A087">创新内容</text>
```

---

## 3. 布局原则

### 3.1 信息流向

```
左 → 右: 数据流/处理流程
上 → 下: 层次/细节展开
```

### 3.2 模块间距

- 模块组之间: 30-50px
- 模块内元素: 10-20px
- 箭头长度: 25-35px

### 3.3 字体规范

```
标题: 18-20px, font-weight="bold"
模块名: 11-12px, font-weight="bold"
说明文字: 9-10px, fill="#666"
公式: 10px, font-style="italic"
```

### 3.4 推荐字体

- **Times New Roman**: 学术论文首选
- **sans-serif**: 标签/图例
- 避免: Arial, Helvetica（太商业）

---

## 4. 信息密度控制

### 4.1 应包含的信息

| 类型 | 示例 |
|------|------|
| 维度/数量 | "33 dims", "5 nodes", "8 heads" |
| 核心公式 | `α'_ij = α_ij · A_causal[i,j]` |
| 关键参数 | "max_lag=10, p<0.05" |
| 性能数据 | "RMSE: 0.0208, -6.7%" |
| 方法说明 | "Monte Carlo, 100 surrogates" |

### 4.2 不应包含的信息

- 完整的算法伪代码（放正文）
- 所有超参数（放附录）
- 详细实验结果（放表格）

---

## 5. NN-SVG 风格参考

来自 https://alexlenail.me/NN-SVG/

### 5.1 3D 堆叠效果

```xml
<!-- 8层堆叠，每层偏移8px -->
<rect width="128" height="128" x="444" y="405" style="fill: rgb(160, 160, 160); stroke: black; stroke-width: 1; opacity: 0.8;"/>
<rect width="128" height="128" x="452" y="413" style="fill: rgb(224, 224, 224); stroke: black; stroke-width: 1; opacity: 0.8;"/>
<!-- ... 交替颜色 ... -->
```

### 5.2 NN-SVG 配色

```
深灰: rgb(160, 160, 160)
浅灰: rgb(224, 224, 224)
透明度: opacity: 0.8
线宽: stroke-width: 0.5 (连接线), 1 (边框)
```

### 5.3 适用场景

- CNN/RNN 层可视化
- 特征图尺寸变化
- **不适合**: 复杂流程图、多模块系统

---

## 6. 迭代经验

### 6.1 常见问题

| 问题 | 解决方案 |
|------|----------|
| "太丑了" | 去掉渐变，用纯色+浅色背景 |
| "信息不够" | 添加维度、参数、公式、性能数据 |
| "不像学术图" | 改用 Times New Roman，降低饱和度 |
| XML解析错误 | `&` 改为 `&amp;` |

### 6.2 迭代流程

```
1. 确定信息架构（哪些模块、什么流程）
2. 选择配色方案（Nature/ColorBrewer）
3. 绘制基础版本
4. 添加细节信息
5. 高亮创新点
6. 调整间距和对齐
7. 用户反馈 → 迭代
```

### 6.3 检查清单

- [ ] 所有创新点有颜色标识
- [ ] 关键公式已展示
- [ ] 维度/参数信息完整
- [ ] 字体统一（Times New Roman）
- [ ] 箭头方向正确
- [ ] Legend 完整
- [ ] XML 语法正确（`&` 转义）

---

## 7. 工具推荐

| 工具 | 用途 | 链接 |
|------|------|------|
| NN-SVG | 神经网络层可视化 | https://alexlenail.me/NN-SVG/ |
| ColorBrewer | 科学配色选择 | https://colorbrewer2.org/ |
| draw.io | 通用流程图 | https://app.diagrams.net/ |
| Inkscape | SVG 编辑 | https://inkscape.org/ |

---

## 8. 完整示例

参考文件: `/Users/mac/computerscience/9碳价预测/linear/COH-GAT/docs/coh_gat_architecture_v8.svg`

**结构**:
```
Input Features → Feature Groups → Causal Discovery → Causal GAT → Output
                                        ↓
                            Interpretability Analysis
```

**四个创新点配色**:
- (1) Activation Patching: 浅青蓝 #4DBBD5
- (2) COH-GAT: 深蓝 #3C5488
- (3) GDELT Indices: 青绿 #00A087
- (4) MC Wavelet: 棕灰 #7E6148

---

*Last Updated: 2026-01-13*
*Based on: COH-GAT architecture diagram v1-v8 iterations*
