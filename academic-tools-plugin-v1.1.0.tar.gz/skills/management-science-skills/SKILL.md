---
name: management-science-skills
description: Curated collection of data science and statistical analysis skills for management science, economics, and social science research. Includes ML interpretability (SHAP), statistical modeling (statsmodels), time series analysis (aeon), visualization (matplotlib, seaborn, plotly), and research workflow tools.
---

# Management Science Skills Collection

A curated subset of scientific skills relevant to management science, economics, finance, and social science research.

## Included Skills (16)

### Machine Learning & Interpretability
- **shap** - Model interpretability with SHAP values
- **scikit-learn** - General machine learning
- **aeon** - Time series ML (classification, forecasting, anomaly detection)

### Statistical Analysis
- **statsmodels** - Econometrics, regression, GLM, ARIMA, VAR
- **statistical-analysis** - Guided statistical test selection
- **pymc** - Bayesian statistical modeling

### Data Processing
- **polars** - High-performance DataFrames
- **exploratory-data-analysis** - EDA workflows

### Visualization
- **matplotlib** - Publication-quality plots
- **seaborn** - Statistical visualizations
- **plotly** - Interactive charts

### Network Analysis
- **networkx** - Graph and network analysis

### Research Workflow
- **literature-review** - Literature search and synthesis
- **scientific-writing** - Academic writing guidance
- **scientific-brainstorming** - Research ideation
- **hypothesis-generation** - Hypothesis development

## Usage

Each skill is in the `skills/` subdirectory with its own SKILL.md containing:
- When to use the skill
- Quick start examples
- Reference documentation
- Best practices

## Skill Selection Guide

| Task | Recommended Skill |
|------|-------------------|
| Model explanation | shap |
| Regression/econometrics | statsmodels |
| Time series forecasting | aeon, statsmodels |
| Data manipulation | polars |
| Statistical tests | statistical-analysis |
| Visualization | matplotlib (static), plotly (interactive) |
| Literature search | literature-review |
