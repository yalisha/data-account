---
name: scientific-figure-pro
description: Generate publication-ready scientific figures using Python and matplotlib. Use this skill whenever the user asks to create academic figures, paper plots, research charts, bar comparisons, trend lines, heatmaps, scatter plots, or any visualization intended for journal/conference submission. Also trigger when the user mentions making figures for a paper, plotting experimental results, creating comparison charts for baselines vs proposed methods, ablation study visualizations, or when they want matplotlib figures that look professional and publication-quality. This skill enforces a unified aesthetic with Helvetica/Arial-like sans fonts, high-contrast semantic palettes, minimal spines, frameless legends, and tight export defaults. Even if the user just says something casual like "帮我画个图" or "plot my results", if the context suggests academic/research use, use this skill.
---

# Scientific Figure Pro

A skill for generating publication-quality scientific figures with a consistent, professional house style. Based on the design patterns from figures published in Nature Machine Intelligence, NeurIPS, ICML, ICLR, and other top venues.

Before creating any figure, read `references/DESIGN_THEORY.md` for the full design philosophy.

## Quick Start

The core helper module is at `scripts/scientific_figure_pro.py`. Copy it to your working directory and use it like this:

```python
import sys
sys.path.insert(0, '/path/to/skill/scripts')
from scientific_figure_pro import (
    apply_publication_style, FigureStyle, PALETTE,
    create_subplots, make_grouped_bar, make_trend,
    make_heatmap, make_scatter, annotate_bars, finalize_figure
)

# Step 1: Apply global style
apply_publication_style(FigureStyle(font_size=16, axes_linewidth=2.5))

# Step 2: Create figure
fig, axes = create_subplots(1, 3, figsize=(18, 5))

# Step 3: Plot using high-level helpers
make_grouped_bar(axes[0], categories, series, labels, ylabel='Score')

# Step 4: Export
finalize_figure(fig, 'output.png', dpi=300)
```

## Style Selection Guide

Choose the right scale for your figure type:

- Dense bar/comparison panels with many methods: `FigureStyle(font_size=24, axes_linewidth=3)`
- Compact trend/scatter/heatmap plots: `FigureStyle(font_size=15, axes_linewidth=2)`
- General purpose / default: `FigureStyle(font_size=16, axes_linewidth=2.5)`

Keep `use_tex=False` unless the user explicitly needs LaTeX math rendering and TeX is installed.

## Available Plot Functions

### make_grouped_bar(ax, categories, series, labels, ...)
For method comparison bar charts. Supports error bars, annotation, custom colors.

### make_trend(ax, x, y_series, labels, ...)
For convergence curves, time series, cumulative plots. Includes optional confidence shadow bands.

### make_heatmap(ax, matrix, x_labels, y_labels, ...)
For correlation matrices, performance grids. Supports cell annotation and custom colormaps.

### make_scatter(ax, x, y, label, color, ...)
For feature visualizations and distribution plots.

### annotate_bars(ax, bars, fmt, fontsize, padding)
Add exact numeric values above bars for precision reading.

### finalize_figure(fig, out_path, formats, dpi, pad)
Export with proper tight_layout and multi-format support.

## Design Principles

These are the non-negotiable rules for all figures produced by this skill. Read `references/DESIGN_THEORY.md` for the full theory.

1. Always remove top and right spines
2. Use frameless legends
3. Use the semantic PALETTE colors — blues for proposed methods, greens for improvements, reds for baselines/contrasts, neutrals for references
4. Set explicit y-limits with modest headroom rather than relying on auto-scaling
5. Use ultra-wide aspect ratios for multi-metric panels (width 3-4x height)
6. For many-method comparisons, dedicate a separate axis panel for the legend
7. Hide x-tick labels when legend is sufficient; don't redundantly label both
8. Export at dpi=300 standard, dpi=600 for dense bar panels
9. Always call finalize_figure to enforce tight_layout before saving

## Palette Reference

Use semantic color assignments:

- blue_main (#0F4D92) and blue_secondary (#3775BA): proposed method, key results
- green_1 (#DDF3DE), green_2 (#AADCA9), green_3 (#8BCF8B): positive variants, improvements
- red_1 (#F6CFCB), red_2 (#E9A6A1), red_strong (#B64342): contrasting baselines, ablations
- neutral (#CFCECE): reference/background categories
- highlight (#FFD700): targeted callouts only
- teal (#42949E), violet (#9A4D8E): additional distinctors when needed

## Common Patterns

### Multi-metric comparison (e.g., AUROC + AUPRC + F1 side by side)

```python
apply_publication_style(FigureStyle(font_size=24, axes_linewidth=3))
fig = plt.figure(figsize=(28, 6))  # ultra-wide

for i, metric in enumerate(metrics):
    ax = fig.add_subplot(1, len(metrics)+1, i+1)
    ax.bar(range(n_methods), values[:, i], color=method_colors)
    ax.set_xticks([])
    ax.set_ylabel(metric, fontsize=32)
    ax.set_ylim([data_min - margin, data_max + margin])

# Dedicated legend panel
ax_legend = fig.add_subplot(1, len(metrics)+1, len(metrics)+1)
ax_legend.legend(handles, labels)
ax_legend.set_axis_off()

finalize_figure(fig, 'comparison.png', dpi=600)
```

### Ablation with alpha encoding

Use the same base color with varying alpha to show component contributions:

```python
alphas = np.linspace(0.2, 1.0, n_ablations)
colors = [(0.22, 0.46, 0.73, a) for a in alphas]
```

### Cumulative trend with event annotations

```python
ax.fill_between(time, zeros, cumulative, color=fill_color, label=name)
ax.plot(time, cumulative, lw=3, c=line_color)
# Add event markers with arrows
ax.annotate(event_name, xy=(x, y), xytext=(x, y+offset),
            arrowprops=dict(arrowstyle='-|>', lw=1.3, color='black'))
```

## Workflow

When the user asks for a figure:

1. Copy `scripts/scientific_figure_pro.py` to the working directory
2. Understand what type of figure is needed (bar comparison, trend, heatmap, etc.)
3. Choose the appropriate FigureStyle scale
4. Write a self-contained Python script that uses the helper functions
5. Run the script and export to PNG (and optionally PDF)
6. Present the result to the user

If the user provides raw data, embed it directly in the script. If they describe the data structure, create synthetic placeholder data that matches their description and clearly mark where they should substitute their real data.
